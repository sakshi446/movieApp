import mongoose from "mongoose";

const bookingSchema = new mongoose.Schema({
    movie:{
        type:mongoose.Types.ObjectId,
        required:true,
    },
    date:{
        type: Date,
        required : true,
    },
    seatNumber:{
        type:Number,
        require:true,
    },
    user:{
        type:mongoose.Types.ObjectId,
        ref:"User",
        required:true,
    },
    bookings:[{type:mongoose.Types.ObjectId, ref:"Booking"}]

})

export default mongoose.model("Booking", bookingSchema)