import mongoose from "mongoose";

const movieSchema = new mongoose.Schema({
    title:{
        type:String,
        required:true,
    },
    description:{
        type:String,
        required: true,

    },
    actors:[{type:String, required:true}],
    releaseDate:{
        type:Date,
        require:true,

    },
    posterUrl:{
        type:String,
        required:true,
    },
    featured:{
        type:Boolean,
   },
   bookings: [{type: String}],
   admin: {
    type:mongoose.Type.ObjectId,
    ref:"Admin",
    required: true,
   },
})

export default mongoose.model("Movie", movieSchema);
