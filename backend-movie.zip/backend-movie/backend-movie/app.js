 
import express from "express";
import mongoose from 'mongoose';
import  dotenv  from'dotenv';
import getAllUsers from "../routes/user-router"
import adminRouter from "../routes/admin-routes";
import { addMovie } from "./controllers/movie-controller";
import movieRouter from "./routes/movie-routes";
import bookingRouter from "./routes/booking-routes";
// import userRouter from '../routes/user-routes';
// const express = require('express');
// const mongoose = require('mongoose');
// const dotenv = require('dotenv');

dotenv.config();
const app = express();




const userRouter = express.Router();

userRouter.get("/ ", getAllUsers) 

//midelwere
app.use(express.json());
app.use("/user", userRouter)
app.use("/admin", adminRouter)
app.use("/movie", movieRouter)
app.use("/booking", bookingRouter)

mongoose.connect(`mongodb+srv://sakshi_malange:${process.env.MONGODB_PASSWORD}@cluster0.molgisw.mongodb.net/retryWrites=true&w=majority`).then(() =>{
    app.listen(3000, ()=>{
        console.log('connect to database and server is running');
})
}).catch((e) => console.log(e ))



