import express from "express";
import { addAdmin, getAdmis } from "../controllers/admin-controller";

const adminRouter = express.Router();

adminRouter.post("/singup", addAdmin)
addAdminRouter.post("/login", addminLogin)
addAdminRouter.get("/", getAdmins)


export default adminRouter;