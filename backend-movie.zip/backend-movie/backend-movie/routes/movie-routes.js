import express from 'express';
import { addMovie, getMovieById } from '../controllers/movie-controller';

const movieRouter =express.Router();

movieRouter.get("/", getAllMovie)
movieRouter.get("/:id", getMovieById
)

movieRouter.post("/", addMovie)

export default movieRouter;